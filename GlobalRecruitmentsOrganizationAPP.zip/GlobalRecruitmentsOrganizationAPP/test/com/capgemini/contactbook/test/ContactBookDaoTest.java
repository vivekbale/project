package com.capgemini.contactbook.test;  

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exception.ContactBookException;




public class ContactBookDaoTest {

    static ContactBookDaoImpl dao;
    static EnquiryBean enquirybean;

    @BeforeClass
    public static void initialize() {
        dao = new ContactBookDaoImpl();
        enquirybean = new EnquiryBean();
    }

    @Test
    public void testAddPatientDetails() throws ContactBookException {

        assertNotNull(dao.addEnquiryDetails(enquirybean));
    }
    
    /************************************
     * Test case for addEnquiryDetails()
     * 
     ************************************/

    @Ignore
    @Test
    public void testAddPatientDetails1() throws ContactBookException {
        assertEquals(1001, dao.addEnquiryDetails(enquirybean));
    }

    /************************************
     * Test case for addEnquiryDetails()
     * 
     ************************************/

    @Test
    public void testAddPatientDetails2() throws ContactBookException {
        
    	enquirybean.setfName("com");
    	enquirybean.setlName("com");
    	enquirybean.setContactNo("9000342237");
    	enquirybean.setpDomain("com");
    	enquirybean.setpLocation("com");
        assertTrue("Data Inserted successfully",
                Integer.parseInt(dao.addEnquiryDetails(enquirybean)) > 1000);

    }
}
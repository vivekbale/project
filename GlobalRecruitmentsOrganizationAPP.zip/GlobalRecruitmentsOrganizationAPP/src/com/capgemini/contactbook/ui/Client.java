package com.capgemini.contactbook.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exception.ContactBookException;
import com.capgemini.contactbook.service.ContactBookService;
import com.capgemini.contactbook.service.ContactBookServiceImpl;




@SuppressWarnings("unused")
public class Client {
	
	
	static Scanner sc = new Scanner(System.in);
		static ContactBookService contactbookService = null;
		static ContactBookServiceImpl contactbookServiceImpl = null;
		static Logger logger = Logger.getRootLogger();

	public static void main(String[] args) throws Exception {
		PropertyConfigurator.configure("resources//log4j.properties");
	EnquiryBean enqry = null;
	int enquiryId ;
	
	int option ;
	
	

	while (true) {

		// show menu
		System.out.println();
		System.out.println();
		System.out.println("   Global Recruitments Organization ");
		System.out.println("_______________________________\n");

		System.out.println("1.Enter Enquiry details ");
		System.out.println("2.View Enquiry Details");
		System.out.println("0.Exit");
		
		System.out.println("________________________________");
		System.out.println("Select an option:");
		// accept option

		try {
			option = sc.nextInt();

			switch (option) {

			case 1:

				while (enqry  == null) {
					enqry   = populateenqry();
					 System.out.println(enqry);
				}

				try {
					contactbookService= new ContactBookServiceImpl();
					enquiryId = contactbookService.addEnquiry(enqry);

					System.out.println("enquiry details  has been successfully registered ");
					System.out.println("enquiry ID Is: " + enquiryId);
					

				} catch (ContactBookException contactBookException) {
					logger.error("exception occured", contactBookException);
					System.out.println("ERROR : "
							+ contactBookException.getMessage());
				} finally {
					
					contactbookService = null;
					enqry = null;
				}

				break;


			case 2:

				System.out.print("Exit Patient Application");
				System.exit(0);
				break;
			default:
				System.out.println("Enter a valid option[1-4]");
			}// end of switch
		}

		catch (InputMismatchException e) {
			sc.nextLine();
			System.err.println("Please enter a numeric value, try again");
	}

	}// end of while
	
	

	}

	private static EnquiryBean populateenqry()throws Exception {

		
		EnquiryBean enqry = new EnquiryBean();

		System.out.println("\nEnquiry Details");

		System.out.println("Enter first name: ");
		enqry.setfName(sc.next());
		
		System.out.println("Enter last name: ");
		enqry.setlName(sc.next());
		
		System.out.println("Enter contact number: ");
		enqry.setContactNo(sc.next());
		
		
		
		System.out.println("Enter prefered domain: ");
		enqry.setpDomain(sc.next());
		
		System.out.println("Enter prefered location: ");
		enqry.setpLocation(sc.next());
		
	
		
        contactbookServiceImpl = new ContactBookServiceImpl();
//System.out.println("After creating patient service impl object");

		try {
			contactbookServiceImpl.isValidEnquiry(enqry);
			
			System.out.println("Thank you " +enqry.getfName()+ enqry.getlName()+ " your Unique Id is " +enqry.getEnqryId()+ " we will contact you shortly");
			
			return enqry ;
		} catch (ContactBookException patientsException) {
			logger.error("exception occured", patientsException);
			System.err.println("Invalid data:");
			System.err.println(patientsException.getMessage() + " \n Try again..");
			System.exit(0);

		}
		return null;

	}

}
